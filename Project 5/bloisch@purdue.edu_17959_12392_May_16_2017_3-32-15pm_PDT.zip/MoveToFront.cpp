class MoveToFront {
	public:
	// apply move-to-front encoding, reading from standard input and writing to standard output
		static void encode()
		{

		}
	// apply move-to-front decoding, reading from standard input and writing to standard output
		static void decode()
		{

		}
};
int main(int argc, char* argv[])
{
	// if argv[1] is '-', apply move-to-front encoding
    // if argv[1] is '+', apply move-to-front decoding
}