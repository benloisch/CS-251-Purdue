I created 4 files for this project.
They are:
Quick3String.java
MoveToFront.java
Wrapper.java
BurrowsWheeler.java

NOTE:
Quick3String.java is already in the algs4.jar
I modified this file and saved it as my own, so you must compile it!

Use these compilation commands to compile all the files necessary to run the project:
javac -cp .:stdlib.jar:algs4.jar Wrapper.java
javac -cp .:stdlib.jar:algs4.jar Quick3string.java
javac -cp .:stdlib.jar:algs4.jar MoveToFront.java
javac -cp .:stdlib.jar:algs4.jar BurrowsWheeler.java