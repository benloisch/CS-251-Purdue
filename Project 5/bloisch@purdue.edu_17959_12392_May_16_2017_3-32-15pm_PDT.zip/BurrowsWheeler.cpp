class BurrowsWheeler {
    public:
    // apply Burrows-Wheeler encoding, reading from standard input and writing to standard output
    	static void encode()
    	{

    	}

    // apply Burrows-Wheeler decoding, reading from standard input and writing to standard output
    	static void decode()
    	{

    	}
};
int main(int argc, char* argv[])
{
	// if argv[1] is '-', apply Burrows-Wheeler encoding
    // if argv[1] is '+', apply Burrows-Wheeler decoding
}