Project 3
Benjamin James Loisch
*Note*
Compiled with the -O2 optimization flag. Without it,
these programs would take much more time to run.